//! adcs-rec/1 run directory: channels.csv (the columns of asils.rec.write, %.9g)
//! and manifest.json -- read by tools/report.py like a MATLAB-twin run.
use crate::config::Config;
use crate::metrics::Derived;
use crate::run::Record;
use serde_json::{json, Value};
use std::fmt::Write as _;
use std::path::Path;

/// C/MATLAB "%.9g".
pub fn g9(x: f64) -> String {
    if x.is_nan() { return "NaN".into(); }
    if x.is_infinite() { return if x > 0.0 { "Inf".into() } else { "-Inf".into() }; }
    if x == 0.0 { return if x.is_sign_negative() { "-0".into() } else { "0".into() }; }
    let e = format!("{:.8e}", x);
    let (mant, exp) = e.split_once('e').unwrap();
    let ex: i32 = exp.parse().unwrap();
    let strip = |s: &str| -> String { if s.contains('.') { s.trim_end_matches('0').trim_end_matches('.').to_string() } else { s.to_string() } };
    if (-4..9).contains(&ex) {
        strip(&format!("{:.*}", (8 - ex).max(0) as usize, x))
    } else {
        format!("{}e{}{:02}", strip(mant), if ex < 0 { '-' } else { '+' }, ex.abs())
    }
}

pub fn write(dir: &Path, c: &Config, rec: &Record, d: &Derived, metrics: &[Value]) -> Result<(), String> {
    std::fs::create_dir_all(dir).map_err(|e| format!("{}: {e}", dir.display()))?;
    let rows = &rec.rows;
    let mut cols: Vec<(String, Vec<f64>)> = vec![];
    let mut col = |name: &str, f: &dyn Fn(usize) -> f64| cols.push((name.to_string(), (0..rows.len()).map(f).collect()));
    col("t_s", &|j| rows[j].t);
    for (i, a) in ["x", "y", "z", "w"].iter().enumerate() { col(&format!("q_{a}"), &|j| rows[j].q[i]); }
    for (i, a) in ["x", "y", "z"].iter().enumerate() { col(&format!("w_{a}_degps"), &|j| rows[j].w[i].to_degrees()); }
    col("rate_degps", &|j| d.rate[j]);
    col("ape_3ax_deg", &|j| d.ape_3ax[j]); col("ape_los_deg", &|j| d.ape_los[j]);
    col("ake_3ax_deg", &|j| d.ake_3ax[j]); col("ake_los_deg", &|j| d.ake_los[j]);
    col("rks_degps", &|j| d.rks[j]);
    col("mode", &|j| rows[j].mode as f64 + 1.0);
    for (i, a) in ["x", "y", "z"].iter().enumerate() { col(&format!("m_{a}_Am2"), &|j| rows[j].m[i]); }
    for (p, name) in ["gg", "aero", "srp", "mag"].iter().enumerate() {
        for (i, a) in ["x", "y", "z"].iter().enumerate() { col(&format!("tau_{name}_{a}_Nm"), &|j| rows[j].tau_dist[p][i]); }
    }
    let nr = rec.nr;
    for (i, a) in ["x", "y", "z"].iter().enumerate() {
        col(&format!("tau_mtq_{a}_Nm"), &|j| rows[j].tau_mtq[i]);
        col(&format!("tau_rw_{a}_Nm"), &|j| if nr > 0 { rows[j].tau_rw[i] } else { f64::NAN });
        col(&format!("B_{a}_T"), &|j| rows[j].b[i]);
        col(&format!("r_{a}_m"), &|j| rows[j].r[i]);
        col(&format!("sun_{a}"), &|j| rows[j].sun_eci[i]);
    }
    for k in 0..nr.max(1) { col(&format!("h_w{}_Nms", k + 1), &|j| if nr > 0 { rows[j].h_w[k] } else { f64::NAN }); }
    for k in 0..rec.ng { col(&format!("gimbal{}_rad", k + 1), &|j| rows[j].delta[k]); }
    for (i, a) in ["x", "y", "z"].iter().enumerate() { col(&format!("tau_rcs_{a}_Nm"), &|j| rows[j].tau_rcs[i]); }
    col("prop_kg", &|j| rows[j].prop_kg);
    col("P_rcs_W", &|j| rows[j].p_rcs);
    col("n_rotors_isolated", &|j| if nr > 0 { rows[j].n_failed as f64 } else { f64::NAN });
    for (i, a) in ["x", "y", "z"].iter().enumerate() { col(&format!("sun_body_{a}"), &|j| rows[j].sun_body[i]); }
    col("P_mtq_W", &|j| rows[j].p_mtq); col("P_rw_W", &|j| rows[j].p_rw);
    col("rho_kgm3", &|j| rows[j].rho); col("shadow_nu", &|j| rows[j].nu);
    col("sun_ok", &|j| rows[j].sun_ok as u8 as f64); col("st_ok", &|j| rows[j].st_ok as u8 as f64); col("ad_ok", &|j| rows[j].ad_ok as u8 as f64);

    let mut s = String::with_capacity(rows.len()*cols.len()*12);
    s.push_str(&cols.iter().map(|c| c.0.as_str()).collect::<Vec<_>>().join(","));
    s.push('\n');
    for j in 0..rows.len() {
        for (i, c) in cols.iter().enumerate() { if i > 0 { s.push(','); } let _ = write!(s, "{}", g9(c.1[j])); }
        s.push('\n');
    }
    std::fs::write(dir.join("channels.csv"), s).map_err(|e| e.to_string())?;

    let mut alg = serde_json::Map::new();
    for (k, v) in &c.alg { alg.insert(k.clone(), json!(v)); }
    let man = json!({
        "schema": "adcs-rec/1", "engine": crate::ENGINE, "owner": "Agastya",
        "scenario": c.id, "case": c.case.id, "case_title": c.case.title, "product": c.dev.id, "family": c.dev.family,
        "label": crate::json::s(&c.scenario, "label", ""), "algorithms": alg, "seed": c.seed, "epoch_utc": c.epoch_utc,
        "duration_s": c.duration_s, "dt_s": c.dt, "wall_s": rec.wall_s,
        "fsw": {"impl": format!("{:?}", rec.fsw_impl).to_lowercase(), "build_id": rec.fsw_build},
        "orbit": {"alt_km": c.alt_km, "inc_deg": c.inc_deg, "ltan_h": c.ltan_h, "raan_deg": rec.raan_rad.to_degrees(), "period_s": c.period_s,
                  "atmosphere": format!("exponential x{}", c.density_scale)},
        "boresight_body": c.dev.boresight, "metrics": metrics,
        "mode_log": rec.mode_log.iter().map(|(t, m)| json!({"t": t, "mode": m})).collect::<Vec<_>>(),
    });
    std::fs::write(dir.join("manifest.json"), serde_json::to_string(&man).unwrap() + "\n").map_err(|e| e.to_string())?;
    Ok(())
}

#[cfg(test)]
mod t {
    #[test]
    fn g9_matches_printf() {
        for (x, s) in [(0.5, "0.5"), (10.0, "10"), (-2.59478359, "-2.59478359"), (4.46144792e-06, "4.46144792e-06"), (-6798619.52, "-6798619.52"),
                       (123456789.0, "123456789"), (1234567891.0, "1.23456789e+09"), (1e-5, "1e-05"), (0.0001, "0.0001")] {
            assert_eq!(super::g9(x), s);
        }
    }
}
